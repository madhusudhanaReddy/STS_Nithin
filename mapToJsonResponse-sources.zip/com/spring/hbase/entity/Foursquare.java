
package com.spring.hbase.entity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "placeid",
    "business_Name",
    "address",
    "phone_number",
    "website",
    "open_hours",
    "category",
    "rating",
    "services_provide",
    "coordinates",
    "photos",
    "photos_count",
    "review",
    "review_count",
    "permanenetly_closed"
})
public class Foursquare {

    @JsonProperty("placeid")
    private String placeid;
    @JsonProperty("business_Name")
    private String businessName;
    @JsonProperty("address")
    private Address___ address;
    @JsonProperty("phone_number")
    private Long phoneNumber;
    @JsonProperty("website")
    private String website;
    @JsonProperty("open_hours")
    private List<Long> openHours = null;
    @JsonProperty("category")
    private List<String> category = null;
    @JsonProperty("rating")
    private Float rating;
    @JsonProperty("services_provide")
    private String servicesProvide;
    @JsonProperty("coordinates")
    private Coordinates___ coordinates;
    @JsonProperty("photos")
    private String photos;
    @JsonProperty("photos_count")
    private Long photosCount;
    @JsonProperty("review")
    private Review___ review;
    @JsonProperty("review_count")
    private Long reviewCount;
    @JsonProperty("permanenetly_closed")
    private Boolean permanenetlyClosed;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("placeid")
    public String getPlaceid() {
        return placeid;
    }

    @JsonProperty("placeid")
    public void setPlaceid(String placeid) {
        this.placeid = placeid;
    }

    @JsonProperty("business_Name")
    public String getBusinessName() {
        return businessName;
    }

    @JsonProperty("business_Name")
    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    @JsonProperty("address")
    public Address___ getAddress() {
        return address;
    }

    @JsonProperty("address")
    public void setAddress(Address___ address) {
        this.address = address;
    }

    @JsonProperty("phone_number")
    public Long getPhoneNumber() {
        return phoneNumber;
    }

    @JsonProperty("phone_number")
    public void setPhoneNumber(Long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @JsonProperty("website")
    public String getWebsite() {
        return website;
    }

    @JsonProperty("website")
    public void setWebsite(String website) {
        this.website = website;
    }

    @JsonProperty("open_hours")
    public List<Long> getOpenHours() {
        return openHours;
    }

    @JsonProperty("open_hours")
    public void setOpenHours(List<Long> openHours) {
        this.openHours = openHours;
    }

    @JsonProperty("category")
    public List<String> getCategory() {
        return category;
    }

    @JsonProperty("category")
    public void setCategory(List<String> category) {
        this.category = category;
    }

    @JsonProperty("rating")
    public Float getRating() {
        return rating;
    }

    @JsonProperty("rating")
    public void setRating(Float rating) {
        this.rating = rating;
    }

    @JsonProperty("services_provide")
    public String getServicesProvide() {
        return servicesProvide;
    }

    @JsonProperty("services_provide")
    public void setServicesProvide(String servicesProvide) {
        this.servicesProvide = servicesProvide;
    }

    @JsonProperty("coordinates")
    public Coordinates___ getCoordinates() {
        return coordinates;
    }

    @JsonProperty("coordinates")
    public void setCoordinates(Coordinates___ coordinates) {
        this.coordinates = coordinates;
    }

    @JsonProperty("photos")
    public String getPhotos() {
        return photos;
    }

    @JsonProperty("photos")
    public void setPhotos(String photos) {
        this.photos = photos;
    }

    @JsonProperty("photos_count")
    public Long getPhotosCount() {
        return photosCount;
    }

    @JsonProperty("photos_count")
    public void setPhotosCount(Long photosCount) {
        this.photosCount = photosCount;
    }

    @JsonProperty("review")
    public Review___ getReview() {
        return review;
    }

    @JsonProperty("review")
    public void setReview(Review___ review) {
        this.review = review;
    }

    @JsonProperty("review_count")
    public Long getReviewCount() {
        return reviewCount;
    }

    @JsonProperty("review_count")
    public void setReviewCount(Long reviewCount) {
        this.reviewCount = reviewCount;
    }

    @JsonProperty("permanenetly_closed")
    public Boolean getPermanenetlyClosed() {
        return permanenetlyClosed;
    }

    @JsonProperty("permanenetly_closed")
    public void setPermanenetlyClosed(Boolean permanenetlyClosed) {
        this.permanenetlyClosed = permanenetlyClosed;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
