
package com.spring.hbase.entity;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "review_date",
    "author_name",
    "rating_by_author",
    "review_by_author"
})
public class Review {

    @JsonProperty("review_date")
    private String reviewDate;
    @JsonProperty("author_name")
    private String authorName;
    @JsonProperty("rating_by_author")
    private String ratingByAuthor;
    @JsonProperty("review_by_author")
    private String reviewByAuthor;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("review_date")
    public String getReviewDate() {
        return reviewDate;
    }

    @JsonProperty("review_date")
    public void setReviewDate(String reviewDate) {
        this.reviewDate = reviewDate;
    }

    @JsonProperty("author_name")
    public String getAuthorName() {
        return authorName;
    }

    @JsonProperty("author_name")
    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    @JsonProperty("rating_by_author")
    public String getRatingByAuthor() {
        return ratingByAuthor;
    }

    @JsonProperty("rating_by_author")
    public void setRatingByAuthor(String ratingByAuthor) {
        this.ratingByAuthor = ratingByAuthor;
    }

    @JsonProperty("review_by_author")
    public String getReviewByAuthor() {
        return reviewByAuthor;
    }

    @JsonProperty("review_by_author")
    public void setReviewByAuthor(String reviewByAuthor) {
        this.reviewByAuthor = reviewByAuthor;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
