
package com.spring.hbase.entity;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "masterid",
    "google",
    "whitepages",
    "yelp",
    "foursquare"
})
public class MapToJsonResponse {

    @JsonProperty("masterid")
    private String masterid;
    @JsonProperty("google")
    private Google google;
    @JsonProperty("whitepages")
    private Whitepages whitepages;
    @JsonProperty("yelp")
    private Yelp yelp;
    @JsonProperty("foursquare")
    private Foursquare foursquare;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("masterid")
    public String getMasterid() {
        return masterid;
    }

    @JsonProperty("masterid")
    public void setMasterid(String masterid) {
        this.masterid = masterid;
    }

    @JsonProperty("google")
    public Google getGoogle() {
        return google;
    }

    @JsonProperty("google")
    public void setGoogle(Google google) {
        this.google = google;
    }

    @JsonProperty("whitepages")
    public Whitepages getWhitepages() {
        return whitepages;
    }

    @JsonProperty("whitepages")
    public void setWhitepages(Whitepages whitepages) {
        this.whitepages = whitepages;
    }

    @JsonProperty("yelp")
    public Yelp getYelp() {
        return yelp;
    }

    @JsonProperty("yelp")
    public void setYelp(Yelp yelp) {
        this.yelp = yelp;
    }

    @JsonProperty("foursquare")
    public Foursquare getFoursquare() {
        return foursquare;
    }

    @JsonProperty("foursquare")
    public void setFoursquare(Foursquare foursquare) {
        this.foursquare = foursquare;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
