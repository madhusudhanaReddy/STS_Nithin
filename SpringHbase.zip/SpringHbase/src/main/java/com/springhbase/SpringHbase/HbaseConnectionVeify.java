package com.springhbase.SpringHbase;

import com.google.protobuf.ServiceException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.client.HBaseAdmin;

import java.io.IOException;

//install hbase locally & hbase master start
public class HbaseConnectionVeify {

	public String connect() throws IOException, ServiceException {

		String connectionStatus = null;

		Configuration config = HBaseConfiguration.create();

		config.set("hbase.zookeeper.quorum","aeamxp00b1.corp.acxiom.net,aeamxp00c1.corp.acxiom.net,aeamxp00d1.corp.acxiom.net");
		config.set("hbase.zookeeper.property.clientPort", "5181");

		try {
			HBaseAdmin.checkHBaseAvailable(config);
			//connectionStatus = "conection success";
		} catch (Exception e) {
			System.out.println("HBase is not running." + e.getMessage());
			connectionStatus = "FAIL::HBase is not running"+e.getMessage();

		}

		return connectionStatus;

		// HBaseClientOperations HBaseClientOperations = new HBaseClientOperations();
		// HBaseClientOperations.run(config);
	}

}