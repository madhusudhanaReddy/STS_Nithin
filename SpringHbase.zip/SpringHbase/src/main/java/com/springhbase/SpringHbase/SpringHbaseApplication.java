package com.springhbase.SpringHbase;

import java.util.Collections;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//import com.javainuse.SpringbootBatchApplication;

@SpringBootApplication(scanBasePackages = {"com.springhbase.SpringHbase"})
public class SpringHbaseApplication {

	public static void main(String[] args) {
		//SpringApplication.run(SpringHbaseApplication.class, args);
		
		SpringApplication app = new SpringApplication(SpringHbaseApplication.class);
	       app.setDefaultProperties(Collections.singletonMap("server.port", "9094"));
	       app.run(args);
	}
}
