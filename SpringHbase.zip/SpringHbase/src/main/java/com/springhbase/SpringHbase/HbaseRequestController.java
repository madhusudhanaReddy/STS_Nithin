package com.springhbase.SpringHbase;




import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.protobuf.ServiceException;



@Controller
public class HbaseRequestController {
	
	@RequestMapping(method = RequestMethod.GET)
	@ResponseBody
	String response(@RequestParam String masterId) throws Exception {
		
		
		return masterId;	
	}
	
	@RequestMapping(method = RequestMethod.GET,value="/test")
	@ResponseBody
	String test() throws Exception {
	
		return "testtttt";	
			
	}
	
	@RequestMapping(method = RequestMethod.GET,value="/connectionTest")
	@ResponseBody
	String verifyConnetion()  {
		HbaseConnectionVeify hbasecon= new HbaseConnectionVeify();
		System.out.println("hbase connection controller");
		 String consts = null;
		try {
			consts = hbasecon.connect();
		} catch (IOException | ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 return consts;
	}
	
	@RequestMapping(method = RequestMethod.GET,value="/connectionTest2")
	@ResponseBody
	String verifyConnetion2()  {
		HbaseConnectionVeify hbasecon= new HbaseConnectionVeify();
		System.out.println("hbase connection controller");
		 String connsts =  verifyConnection2();	
		 return connsts;
	}
	
	
	@RequestMapping(method = RequestMethod.GET,value="/getbymaster")
	@ResponseBody
	String getBymsterId()  {
		HbaseConnectionVeify hbasecon= new HbaseConnectionVeify();
		System.out.println("hbase getBymsterId");
		String masterData = null;
		try {
			masterData = getMasterData();
		} catch (IOException | ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return masterData;
	}
	
	
	private String getMasterData() throws IOException, ServiceException {

		String connectionStatus = "SUCCESS";
		String getResult;


		Configuration config = HBaseConfiguration.create();

		config.set("hbase.zookeeper.quorum","aeamxp00b1.corp.acxiom.net,aeamxp00c1.corp.acxiom.net,aeamxp00d1.corp.acxiom.net");
		config.set("hbase.zookeeper.property.clientPort", "5181");
		
		
		/*Configuration config = HBaseConfiguration.create();

		// config.setInt("timeout", 120000);
		config.set("hbase.zookeeper.quorum",
				"aeamxp0030.corp.acxiom.net,aeamxp0051.corp.acxiom.net,aeamxp0050.corp.acxiom.net");
		// config.set("zookeeper.znode.parent", "/hbase-unsecure");
		config.set("hbase.zookeeper.property.clientPort", "2181");
		// config.setInt("hbase.client.scanner.caching", 10000);
*/
		try {
			HBaseAdmin.checkHBaseAvailable(config);
			HBaseClientOperations HBaseClientOperations = new HBaseClientOperations();
			getResult= HBaseClientOperations.get(config);
		} catch (Exception e) {
			System.out.println("HBase is not running." + e.getMessage());
			getResult = "FAIL::HBase is not running"+e.toString();

		}
		
			
		return getResult;
		
	}
	
	private String verifyConnection2() {
		
		String connStatus = null;
		
	       Configuration config = HBaseConfiguration.create();

	      // Instantiating HTable class
	      //HTable table = new HTable(config, "emp");
	      
	      //config.setInt("timeout", 120000);
	      config.set("hbase.zookeeper.quorum", "aeamxp0030.corp.acxiom.net,aeamxp0051.corp.acxiom.net,aeamxp0050.corp.acxiom.net");
	      // config.set("hbase.zookeeper.quorum", "aeamxp0030.corp.acxiom.net");
	      //config.set("zookeeper.znode.parent", "/hbase-unsecure");
	      config.set("hbase.zookeeper.property.clientPort", "2181");
	      //config.setInt("hbase.client.scanner.caching", 10000);
	      System.out.println("hi hhh");
	      Connection connection=null;
	     
	    	   try {
				connection = ConnectionFactory.createConnection(config);
				//connStatus="connection success";
				System.out.println("connection::"+connection);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				connStatus="connection failed"+e.getStackTrace();
				System.out.println("errrr");
				//e.printStackTrace();
			}
			return connStatus;
	    	 
	}  
	
	@RequestMapping(method = RequestMethod.GET,value="/scanbymaster")
	@ResponseBody
	public  String scanData(){

		//String connectionStatus = "SUCCESS";
		String getResult=null;


		Configuration config = HBaseConfiguration.create();

		config.set("hbase.zookeeper.quorum","aeamxp00b1.corp.acxiom.net,aeamxp00c1.corp.acxiom.net,aeamxp00d1.corp.acxiom.net");
		config.set("hbase.zookeeper.property.clientPort", "5181");
		
		try {
			HBaseAdmin.checkHBaseAvailable(config);
			HBaseClientOperations HBaseClientOperations = new HBaseClientOperations();
			getResult= HBaseClientOperations.scan(config);
		} catch (Exception e) {
			System.out.println("HBase is not running." + e.getMessage());
			getResult = "Error occrued Ehile scning data"+e.toString();

		}
		
			
		return getResult;
		
	}
	
	
}
