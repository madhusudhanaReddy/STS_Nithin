package com.springhbase.SpringHbase;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.filter.*;
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp;
import org.apache.hadoop.hbase.filter.FilterList.Operator;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class HBaseClientOperations {
	// private final static byte[] cellData = Bytes.toBytes("cell_data");

	private final TableName table1 = TableName.valueOf("test_1");
	private final String family1 = "dt";

	private final byte[] row1 = Bytes.toBytes("1");
	private final byte[] qualifier1 = Bytes.toBytes("masterid");

	private void get(Table table) throws IOException {

		Get g = new Get(row1);
		Result r = table.get(g);
		byte[] value = r.getValue(family1.getBytes(), qualifier1);

		System.out.println("Fetched value: " + Bytes.toString(value));
		// assert Arrays.equals(cellData, value);
		System.out.println("Done. ");
	}

	private void put(Admin admin, Table table) throws IOException {

	}

	public void run(Configuration config) throws IOException {
		try (Connection connection = ConnectionFactory.createConnection(config)) {
			Table table = connection.getTable(table1);

		}
	}

	public String get(Configuration config) {

		String finalresult;

		try {
			Connection connection = ConnectionFactory.createConnection(config);
			TableName table1 = TableName.valueOf("test_1");

			Table table = connection.getTable(TableName.valueOf("table1"));

			// Instantiating Get class
			Get g = new Get(Bytes.toBytes("1"));

			// Reading the data
			Result result = table.get(g);

			// Reading values from Result class object
			byte[] masterid = result.getValue(Bytes.toBytes("dt"), Bytes.toBytes("masterid"));
			byte[] value = result.getValue(Bytes.toBytes("dt"), Bytes.toBytes("company"));

			byte[] value1 = result.getValue(Bytes.toBytes("dt"), Bytes.toBytes("name"));

			// Printing the values
			String masterid_1 = Bytes.toString(masterid);
			String company = Bytes.toString(value);
			String name = Bytes.toString(value1);

			finalresult = "masterid_1:::" + masterid_1 + "company:::" + company + "name::" + name;

			System.out.println("masterif: " + masterid_1 + " company: " + company + "name" + name);

		} catch (Exception e) {

			finalresult = "Error while fetching::" + e.getClass();
		}
		return finalresult;
	}
	
	
	public  String  scan(Configuration config) throws IOException {
        
		
        String finalScanRes = null;
        
        try {
        	Connection connection = ConnectionFactory.createConnection(config);
			TableName table1 = TableName.valueOf("test_1");

			Table table = connection.getTable(TableName.valueOf("table1"));
            Filter filter = new SingleColumnValueFilter(Bytes
                    .toBytes("column1"), null, CompareOp.EQUAL, Bytes
                    .toBytes("aaa"));
            Scan s = new Scan();
            s.setFilter(filter);
            ResultScanner rs = table.getScanner(s);
            for (Result r : rs) {
                for (KeyValue keyValue : r.raw()) {
                	finalScanRes="Scan Result Some data is getting";
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            finalScanRes="Getting Error while fetching Scan Result::::"+e.getClass();
        }
        
        return finalScanRes;
        
    }
	

}